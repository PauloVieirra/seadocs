// API Service - Configurável para qualquer banco de dados

import { manusAPIService, type ManusConfig } from './manus-api';

export interface DatabaseConfig {
  host: string;
  port: number;
  database: string;
  username: string;
  password: string;
  type: 'postgresql' | 'mysql' | 'mongodb' | 'sqlserver';
}

export interface AIConfig {
  apiKey: string;
  provider?: 'openai' | 'anthropic' | 'manus' | 'custom';
}

export { type ManusConfig } from './manus-api';

export interface User {
  id: string;
  email: string;
  name: string;
  role: 'user' | 'manager' | 'admin';
  managerId?: string;
  createdAt: string;
}

export interface Project {
  id: string;
  name: string;
  description?: string;
  creatorId: string;
  creatorName: string;
  status: 'draft' | 'in-progress' | 'review' | 'approved';
  createdAt: string;
  updatedAt: string;
}

export interface Document {
  id: string;
  projectId: string;
  content: DocumentContent;
  version: number;
  updatedAt: string;
  updatedBy: string;
}

export interface DocumentContent {
  sections: DocumentSection[];
}

export interface DocumentSection {
  id: string;
  title: string;
  content: string;
  isEditable: boolean;
}

export interface UploadedFile {
  id: string;
  projectId: string;
  name: string;
  type: 'pdf' | 'doc' | 'docx';
  size: number;
  status: 'processing' | 'processed' | 'error';
  uploadedBy: string;
  uploadedAt: string;
}

export interface AuditLog {
  id: string;
  projectId: string;
  action: string;
  userId: string;
  userName: string;
  details: string;
  timestamp: string;
}

class APIService {
  private dbConfig: DatabaseConfig | null = null;
  private aiConfig: AIConfig | null = null;
  private currentUser: User | null = null;
  
  // Mock data para demonstração
  private mockUsers: User[] = [
    {
      id: '1',
      email: 'admin@empresa.com',
      name: 'Admin Sistema',
      role: 'admin',
      createdAt: new Date().toISOString()
    },
    {
      id: '2',
      email: 'gerente@empresa.com',
      name: 'Gerente de Projeto',
      role: 'manager',
      createdAt: new Date().toISOString()
    },
    {
      id: '3',
      email: 'usuario@empresa.com',
      name: 'Usuário Padrão',
      role: 'user',
      managerId: '2',
      createdAt: new Date().toISOString()
    }
  ];

  private mockProjects: Project[] = [
    {
      id: '1',
      name: 'Sistema de Gestão Financeira',
      description: 'Especificação de requisitos para o novo sistema de gestão financeira',
      creatorId: '3',
      creatorName: 'Usuário Padrão',
      status: 'in-progress',
      createdAt: new Date(2025, 11, 1).toISOString(),
      updatedAt: new Date(2025, 11, 10).toISOString()
    },
    {
      id: '2',
      name: 'Portal do Cliente',
      description: 'Documentação completa do portal de autoatendimento',
      creatorId: '2',
      creatorName: 'Gerente de Projeto',
      status: 'review',
      createdAt: new Date(2025, 10, 15).toISOString(),
      updatedAt: new Date(2025, 11, 12).toISOString()
    }
  ];

  private mockDocuments: Map<string, Document> = new Map([
    ['1', {
      id: '1',
      projectId: '1',
      version: 3,
      updatedAt: new Date().toISOString(),
      updatedBy: 'Usuário Padrão',
      content: {
        sections: [
          {
            id: 'intro',
            title: '1. Introdução',
            content: 'Este documento especifica os requisitos para o Sistema de Gestão Financeira da empresa.',
            isEditable: true
          },
          {
            id: 'overview',
            title: '2. Visão Geral do Sistema',
            content: 'O sistema tem como objetivo automatizar processos financeiros, incluindo contas a pagar, contas a receber e conciliação bancária.',
            isEditable: true
          },
          {
            id: 'functional',
            title: '3. Requisitos Funcionais',
            content: 'RF001: O sistema deve permitir o cadastro de fornecedores.\nRF002: O sistema deve gerar relatórios de fluxo de caixa.\nRF003: O sistema deve integrar com bancos via API.',
            isEditable: true
          },
          {
            id: 'nonfunctional',
            title: '4. Requisitos Não Funcionais',
            content: 'RNF001: O sistema deve suportar 1000 usuários simultâneos.\nRNF002: Tempo de resposta inferior a 2 segundos.',
            isEditable: true
          },
          {
            id: 'business-rules',
            title: '5. Regras de Negócio',
            content: 'RN001: Pagamentos acima de R$ 10.000 requerem dupla aprovação.\nRN002: Conciliação bancária deve ser realizada diariamente.',
            isEditable: true
          },
          {
            id: 'constraints',
            title: '6. Premissas e Restrições',
            content: 'Premissa: API bancária estará disponível.\nRestrição: Sistema deve estar em conformidade com a LGPD.',
            isEditable: true
          }
        ]
      }
    }]
  ]);

  private mockFiles: Map<string, UploadedFile[]> = new Map();
  private mockAuditLogs: Map<string, AuditLog[]> = new Map();

  // Configuração do banco de dados
  async configurarBancoDeDados(config: DatabaseConfig): Promise<boolean> {
    try {
      // Aqui seria feita a conexão real com o banco de dados
      // usando as credenciais fornecidas
      console.log('Configurando conexão com banco de dados:', {
        type: config.type,
        host: config.host,
        port: config.port,
        database: config.database
      });
      
      this.dbConfig = config;
      localStorage.setItem('db_config', JSON.stringify(config));
      return true;
    } catch (error) {
      console.error('Erro ao configurar banco de dados:', error);
      return false;
    }
  }

  getConfiguracao(): DatabaseConfig | null {
    if (this.dbConfig) return this.dbConfig;
    
    const stored = localStorage.getItem('db_config');
    if (stored) {
      this.dbConfig = JSON.parse(stored);
      return this.dbConfig;
    }
    
    return null;
  }

  // Configuração da IA
  async configurarIA(config: AIConfig): Promise<boolean> {
    try {
      // Aqui seria feita a configuração real da IA
      // usando as credenciais fornecidas
      console.log('Configurando IA:', {
        provider: config.provider,
        apiKey: config.apiKey
      });
      
      this.aiConfig = config;
      localStorage.setItem('ai_config', JSON.stringify(config));
      return true;
    } catch (error) {
      console.error('Erro ao configurar IA:', error);
      return false;
    }
  }

  getAIConfiguracao(): AIConfig | null {
    if (this.aiConfig) return this.aiConfig;
    
    const stored = localStorage.getItem('ai_config');
    if (stored) {
      this.aiConfig = JSON.parse(stored);
      return this.aiConfig;
    }
    
    return null;
  }

  // Autenticação
  async login(email: string, password: string): Promise<User | null> {
    // Permite login sem cadastro - cria usuário automaticamente
    let user = this.mockUsers.find(u => u.email === email);
    
    if (!user) {
      // Cria usuário automaticamente no primeiro login
      const name = email.split('@')[0].split('.').map(part => 
        part.charAt(0).toUpperCase() + part.slice(1)
      ).join(' ');
      
      user = {
        id: Date.now().toString(),
        email,
        name,
        role: 'user',
        createdAt: new Date().toISOString()
      };
      
      this.mockUsers.push(user);
    }
    
    this.currentUser = user;
    localStorage.setItem('current_user', JSON.stringify(user));
    return user;
  }

  async register(email: string, password: string, name: string): Promise<User | null> {
    const newUser: User = {
      id: Date.now().toString(),
      email,
      name,
      role: 'user',
      createdAt: new Date().toISOString()
    };
    
    this.mockUsers.push(newUser);
    this.currentUser = newUser;
    localStorage.setItem('current_user', JSON.stringify(newUser));
    return newUser;
  }

  logout(): void {
    this.currentUser = null;
    localStorage.removeItem('current_user');
  }

  getCurrentUser(): User | null {
    if (this.currentUser) return this.currentUser;
    
    const stored = localStorage.getItem('current_user');
    if (stored) {
      this.currentUser = JSON.parse(stored);
      return this.currentUser;
    }
    
    return null;
  }

  // Projetos
  async getProjects(): Promise<Project[]> {
    const user = this.getCurrentUser();
    if (!user) return [];

    // RBAC: Filtrar projetos baseado no papel do usuário
    if (user.role === 'admin') {
      return this.mockProjects;
    }

    if (user.role === 'manager') {
      // Gerente vê seus projetos + projetos de usuários sob supervisão
      return this.mockProjects.filter(p => 
        p.creatorId === user.id || 
        this.mockUsers.find(u => u.id === p.creatorId)?.managerId === user.id
      );
    }

    // Usuário padrão vê apenas seus projetos
    return this.mockProjects.filter(p => p.creatorId === user.id);
  }

  async createProject(name: string, description?: string): Promise<Project> {
    const user = this.getCurrentUser();
    if (!user) throw new Error('Usuário não autenticado');

    const newProject: Project = {
      id: Date.now().toString(),
      name,
      description,
      creatorId: user.id,
      creatorName: user.name,
      status: 'draft',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    this.mockProjects.push(newProject);

    // Criar documento inicial
    const initialDoc: Document = {
      id: newProject.id,
      projectId: newProject.id,
      version: 1,
      updatedAt: new Date().toISOString(),
      updatedBy: user.name,
      content: {
        sections: [
          { id: 'intro', title: '1. Introdução', content: '', isEditable: true },
          { id: 'overview', title: '2. Visão Geral do Sistema', content: '', isEditable: true },
          { id: 'functional', title: '3. Requisitos Funcionais', content: '', isEditable: true },
          { id: 'nonfunctional', title: '4. Requisitos Não Funcionais', content: '', isEditable: true },
          { id: 'business-rules', title: '5. Regras de Negócio', content: '', isEditable: true },
          { id: 'constraints', title: '6. Premissas e Restrições', content: '', isEditable: true }
        ]
      }
    };

    this.mockDocuments.set(newProject.id, initialDoc);

    // Log de auditoria
    this.addAuditLog(newProject.id, 'project_created', user.id, user.name, `Projeto "${name}" criado`);

    return newProject;
  }

  async getProject(projectId: string): Promise<Project | null> {
    return this.mockProjects.find(p => p.id === projectId) || null;
  }

  // Documentos
  async getDocument(projectId: string): Promise<Document | null> {
    return this.mockDocuments.get(projectId) || null;
  }

  async updateDocument(projectId: string, content: DocumentContent): Promise<Document> {
    const user = this.getCurrentUser();
    if (!user) throw new Error('Usuário não autenticado');

    const currentDoc = this.mockDocuments.get(projectId);
    const updatedDoc: Document = {
      id: projectId,
      projectId,
      version: (currentDoc?.version || 0) + 1,
      updatedAt: new Date().toISOString(),
      updatedBy: user.name,
      content
    };

    this.mockDocuments.set(projectId, updatedDoc);

    // Log de auditoria
    this.addAuditLog(projectId, 'document_edited', user.id, user.name, 'Documento editado manualmente');

    return updatedDoc;
  }

  async generateWithAI(projectId: string, sectionId: string): Promise<string> {
    const user = this.getCurrentUser();
    if (!user) throw new Error('Usuário não autenticado');

    const aiConfig = this.getAIConfiguracao();
    if (!aiConfig || !aiConfig.apiKey) {
      throw new Error('Configure a API da IA nas configurações antes de gerar conteúdo');
    }

    // Se o provider for Manus, usar serviço específico
    if (aiConfig.provider === 'manus') {
      try {
        const sectionTitles: Record<string, string> = {
          'intro': 'Introdução',
          'overview': 'Visão Geral do Sistema',
          'functional': 'Requisitos Funcionais',
          'nonfunctional': 'Requisitos Não Funcionais',
          'business-rules': 'Regras de Negócio',
          'constraints': 'Premissas e Restrições'
        };

        const response = await manusAPIService.generateSectionContent(
          projectId,
          sectionTitles[sectionId] || sectionId,
          sectionId
        );

        // Log de auditoria
        this.addAuditLog(projectId, 'ai_generation_manus', user.id, user.name, `Manus IA gerou conteúdo para seção "${sectionId}"`);

        return response;
      } catch (error: any) {
        console.error('Erro ao gerar com Manus:', error);
        throw error;
      }
    }

    // Fluxo normal para OpenAI/Anthropic
    const files = await this.getProjectFiles(projectId);
    const processedFiles = files.filter(f => f.status === 'processed');

    // Preparar contexto para a IA
    const sectionTitles: Record<string, string> = {
      'intro': 'Introdução',
      'overview': 'Visão Geral do Sistema',
      'functional': 'Requisitos Funcionais',
      'nonfunctional': 'Requisitos Não Funcionais',
      'business-rules': 'Regras de Negócio',
      'constraints': 'Premissas e Restrições'
    };

    const prompt = `Você é um assistente especializado em Engenharia de Requisitos. \nAnalise os documentos fornecidos e gere conteúdo para a seção "${sectionTitles[sectionId]}" de uma especificação de requisitos.\n\nIMPORTANTE:\n- Base-se APENAS nos documentos fornecidos\n- Se não encontrar informação relevante, escreva "Não identificado: [breve explicação]"\n- Para requisitos funcionais, use o formato: RF001, RF002, etc.\n- Para requisitos não funcionais, use: RNF001, RNF002, etc.\n- Para regras de negócio, use: RN001, RN002, etc.\n- Seja objetivo e técnico\n\nDocumentos disponíveis: ${processedFiles.map(f => f.name).join(', ') || 'Nenhum documento enviado ainda'}\n\nGere o conteúdo:`;

    try {
      console.log('Chamando API da IA...', { provider: aiConfig.provider, sectionId });
      
      // Chamada real à API da IA
      const response = await this.callAIAPI(aiConfig, prompt);
      
      console.log('Resposta da IA recebida');

      // Log de auditoria
      this.addAuditLog(projectId, 'ai_generation', user.id, user.name, `IA gerou conteúdo para seção "${sectionId}"`);

      return response;
    } catch (error: any) {
      console.error('Erro ao chamar API da IA:', error);
      
      // Se a API falhar, retornar mensagem de erro informativa
      if (error.message?.includes('API key')) {
        throw new Error('Chave de API inválida. Verifique suas configurações.');
      } else if (error.message?.includes('rate limit')) {
        throw new Error('Limite de requisições excedido. Tente novamente em alguns minutos.');
      } else if (error.message?.includes('network')) {
        throw new Error('Erro de conexão. Verifique sua internet.');
      } else {
        throw new Error('Erro ao se comunicar com a IA: ' + (error.message || 'Erro desconhecido'));
      }
    }
  }

  // Método auxiliar para chamar a API da IA
  private async callAIAPI(config: AIConfig, prompt: string): Promise<string> {
    const provider = config.provider || 'openai';

    if (provider === 'openai') {
      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${config.apiKey}`
        },
        body: JSON.stringify({
          model: 'gpt-4o-mini',
          messages: [
            {
              role: 'system',
              content: 'Você é um especialista em Engenharia de Requisitos e Análise de Sistemas.'
            },
            {
              role: 'user',
              content: prompt
            }
          ],
          temperature: 0.7,
          max_tokens: 2000
        })
      });

      if (!response.ok) {
        const error = await response.json().catch(() => ({}));
        console.error('Erro da API OpenAI:', error);
        
        if (response.status === 401) {
          throw new Error('API key inválida ou expirada');
        } else if (response.status === 429) {
          throw new Error('rate limit exceeded');
        } else {
          throw new Error(`Erro HTTP ${response.status}: ${error.error?.message || 'Erro desconhecido'}`);
        }
      }

      const data = await response.json();
      return data.choices[0].message.content;
      
    } else if (provider === 'anthropic') {
      const response = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': config.apiKey,
          'anthropic-version': '2023-06-01'
        },
        body: JSON.stringify({
          model: 'claude-3-5-sonnet-20241022',
          max_tokens: 2000,
          messages: [
            {
              role: 'user',
              content: prompt
            }
          ]
        })
      });

      if (!response.ok) {
        const error = await response.json().catch(() => ({}));
        console.error('Erro da API Anthropic:', error);
        
        if (response.status === 401) {
          throw new Error('API key inválida ou expirada');
        } else if (response.status === 429) {
          throw new Error('rate limit exceeded');
        } else {
          throw new Error(`Erro HTTP ${response.status}: ${error.error?.message || 'Erro desconhecido'}`);
        }
      }

      const data = await response.json();
      return data.content[0].text;
      
    } else if (provider === 'manus') {
      // Usar API Manus para chat/geração
      const manusConfig: ManusConfig = {
        apiKey: config.apiKey,
        endpoint: (config as any).endpoint
      };
      
      // Chamar API Manus através do serviço
      const result = await manusAPIService.chat({
        messages: [
          {
            role: 'user',
            content: prompt
          }
        ],
        temperature: 0.7,
        maxTokens: 2000
      });
      
      return result;
      
    } else {
      // Para API customizada
      throw new Error('Provider de IA não suportado. Use "openai", "anthropic" ou "manus".');
    }
  }

  // Chat com IA
  async chatWithAI(projectId: string, message: string, context?: { sectionId?: string }): Promise<string> {
    console.log('chatWithAI chamado:', { projectId, message });
    
    const user = this.getCurrentUser();
    if (!user) {
      console.error('Usuário não autenticado');
      throw new Error('Usuário não autenticado');
    }

    console.log('Usuário autenticado:', user);

    const aiConfig = this.getAIConfiguracao();
    if (!aiConfig || !aiConfig.apiKey) {
      throw new Error('Configure a API da IA nas configurações antes de usar o chat');
    }

    // Se for Manus, usar chat com contexto completo dos documentos
    if (aiConfig.provider === 'manus') {
      try {
        const manusDocuments = await manusAPIService.getProjectDocuments(projectId);
        const document = await this.getDocument(projectId);
        
        // Preparar contexto do documento atual
        let documentContext = '';
        if (document) {
          documentContext = document.content.sections
            .map(s => `${s.title}:\n${s.content || '[Vazio]'}`)
            .join('\n\n');
        }

        const response = await manusAPIService.chat({
          messages: [
            {
              role: 'user',
              content: message
            }
          ],
          context: {
            documents: manusDocuments,
            projectInfo: `DOCUMENTO ATUAL DO PROJETO:\n${documentContext}`
          },
          temperature: 0.7,
          maxTokens: 2000
        });

        // Log de auditoria
        this.addAuditLog(projectId, 'ai_chat_manus', user.id, user.name, `Chat Manus: "${message.substring(0, 50)}..."`);

        return response;
      } catch (error: any) {
        console.error('Erro no chat Manus:', error);
        throw error;
      }
    }

    // Fluxo normal para OpenAI/Anthropic
    const files = await this.getProjectFiles(projectId);
    const document = await this.getDocument(projectId);
    const processedFiles = files.filter(f => f.status === 'processed');

    console.log('Contexto do chat:', { 
      aiConfigPresent: !!aiConfig, 
      filesCount: files.length, 
      documentPresent: !!document 
    });

    // Preparar contexto do documento para a IA
    let documentContext = '';
    if (document) {
      documentContext = document.content.sections
        .map(s => `${s.title}:\\n${s.content || '[Vazio]'}`)
        .join('\\n\\n');
    }

    const prompt = `Você é um assistente especializado em Engenharia de Requisitos trabalhando em um documento de especificação.\n\nCONTEXTO DO PROJETO:\n- Documentos processados: ${processedFiles.map(f => f.name).join(', ') || 'Nenhum'}\n- Total de arquivos: ${files.length}\n\nDOCUMENTO ATUAL:\n${documentContext || 'Documento vazio'}\n\nMENSAGEM DO USUÁRIO: ${message}\n\nResponda de forma clara e objetiva. Se o usuário pedir para adicionar, editar ou revisar conteúdo, seja específico sobre o que você faria. Mantenha o tom profissional e técnico.`;

    try {
      console.log('Chamando API da IA para chat...');
      
      const response = await this.callAIAPI(aiConfig, prompt);
      
      console.log('Resposta do chat recebida');

      // Log de auditoria
      this.addAuditLog(projectId, 'ai_chat', user.id, user.name, `Chat: \"${message.substring(0, 50)}...\"`);

      return response;
    } catch (error: any) {
      console.error('Erro ao chamar API da IA no chat:', error);
      
      // Mensagens de erro mais específicas
      if (error.message?.includes('API key')) {
        throw new Error('Chave de API inválida. Verifique suas configurações.');
      } else if (error.message?.includes('rate limit')) {
        throw new Error('Limite de requisições excedido. Aguarde alguns minutos.');
      } else if (error.message?.includes('network') || error.message?.includes('Failed to fetch')) {
        throw new Error('Erro de conexão. Verifique sua internet.');
      } else {
        throw new Error('Erro ao se comunicar com a IA: ' + (error.message || 'Erro desconhecido'));
      }
    }
  }

  async applyAIEdit(projectId: string, sectionId: string, instruction: string): Promise<string> {
    const user = this.getCurrentUser();
    if (!user) throw new Error('Usuário não autenticado');

    // Simula aplicação de edição pela IA
    const mockEdits: Record<string, string> = {
      'adicionar_requisito': 'RF004: O sistema deve permitir exportação de dados em formato CSV e PDF.',
      'melhorar_texto': 'Texto melhorado com mais detalhes e clareza baseado nos documentos analisados.',
      'expandir_secao': 'Conteúdo expandido com informações adicionais extraídas dos documentos do projeto.'
    };

    const edit = mockEdits['adicionar_requisito'] || 'Edição aplicada conforme solicitado.';

    // Log de auditoria
    this.addAuditLog(projectId, 'ai_edit', user.id, user.name, `IA editou seção "${sectionId}": ${instruction}`);

    return edit;
  }

  // Upload de arquivos
  async uploadFile(projectId: string, file: File): Promise<UploadedFile> {
    const user = this.getCurrentUser();
    if (!user) throw new Error('Usuário não autenticado');

    const uploadedFile: UploadedFile = {
      id: Date.now().toString(),
      projectId,
      name: file.name,
      type: file.name.endsWith('.pdf') ? 'pdf' : file.name.endsWith('.docx') ? 'docx' : 'doc',
      size: file.size,
      status: 'processing',
      uploadedBy: user.name,
      uploadedAt: new Date().toISOString()
    };

    const projectFiles = this.mockFiles.get(projectId) || [];
    projectFiles.push(uploadedFile);
    this.mockFiles.set(projectId, projectFiles);

    // Processar documento com Manus se configurado
    const aiConfig = this.getAIConfiguracao();
    if (aiConfig?.provider === 'manus' && aiConfig.apiKey) {
      try {
        console.log('Processando documento com Manus...', file.name);
        const manusConfig: ManusConfig = {
          apiKey: aiConfig.apiKey,
          endpoint: (aiConfig as any).endpoint
        };
        
        // Processar documento com Manus
        const manusDoc = await manusAPIService.processDocument(projectId, file);
        console.log('Documento processado com Manus:', manusDoc.id);
        
        // Atualizar status
        uploadedFile.status = 'processed';
        
        // Log de auditoria específico
        this.addAuditLog(
          projectId, 
          'file_processed_manus', 
          user.id, 
          user.name, 
          `Documento \"${file.name}\" processado pela IA Manus`
        );
      } catch (error: any) {
        console.error('Erro ao processar documento com Manus:', error);
        uploadedFile.status = 'error';
        this.addAuditLog(
          projectId, 
          'file_processing_error', 
          user.id, 
          user.name, 
          `Erro ao processar \"${file.name}\": ${error.message}`
        );
      }
    } else {
      // Simula processamento local se Manus não estiver configurado
      setTimeout(() => {
        uploadedFile.status = 'processed';
      }, 2000);
    }

    // Log de auditoria
    this.addAuditLog(projectId, 'file_uploaded', user.id, user.name, `Arquivo \"${file.name}\" enviado`);

    return uploadedFile;
  }

  async getProjectFiles(projectId: string): Promise<UploadedFile[]> {
    return this.mockFiles.get(projectId) || [];
  }

  // Auditoria
  private addAuditLog(projectId: string, action: string, userId: string, userName: string, details: string): void {
    const log: AuditLog = {
      id: Date.now().toString(),
      projectId,
      action,
      userId,
      userName,
      details,
      timestamp: new Date().toISOString()
    };

    const logs = this.mockAuditLogs.get(projectId) || [];
    logs.unshift(log);
    this.mockAuditLogs.set(projectId, logs);
  }

  async getAuditLogs(projectId: string): Promise<AuditLog[]> {
    return this.mockAuditLogs.get(projectId) || [];
  }

  // Colaboradores ativos (mock para simulação)
  getActiveUsers(projectId: string): User[] {
    // Mock: retorna alguns usuários como "ativos"
    return this.mockUsers.slice(0, 2);
  }
}

export const apiService = new APIService();