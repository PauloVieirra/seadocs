import { useEffect, useState } from 'react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from './ui/sheet';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { ArrowLeft, Settings, Users, Save, Sparkles } from 'lucide-react';
import { apiService, type Project, type Document, type User } from '../../services/api';
import { DocumentEditor } from './DocumentEditor';
import { DataSourcesPanel } from './DataSourcesPanel';
import { AuditPanel } from './AuditPanel';
import { AIChat } from './AIChat';
import { Avatar, AvatarFallback } from './ui/avatar';

interface ProjectEditorProps {
  projectId: string;
  onBack: () => void;
}

export function ProjectEditor({ projectId, onBack }: ProjectEditorProps) {
  const [project, setProject] = useState<Project | null>(null);
  const [document, setDocument] = useState<Document | null>(null);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [activeUsers, setActiveUsers] = useState<User[]>([]);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    loadProject();
    loadDocument();
    loadActiveUsers();
  }, [projectId]);

  const loadProject = async () => {
    const data = await apiService.getProject(projectId);
    setProject(data);
  };

  const loadDocument = async () => {
    const data = await apiService.getDocument(projectId);
    setDocument(data);
  };

  const loadActiveUsers = async () => {
    const users = apiService.getActiveUsers(projectId);
    setActiveUsers(users);
  };

  const handleSave = async (content: Document['content']) => {
    setSaving(true);
    const updatedDoc = await apiService.updateDocument(projectId, content);
    setDocument(updatedDoc);
    setTimeout(() => setSaving(false), 1000);
  };

  if (!project || !document) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Carregando projeto...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white flex flex-col">
      {/* Header */}
      <header className="border-b border-gray-200 bg-white sticky top-0 z-10">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="sm" onClick={onBack}>
                <ArrowLeft className="w-4 h-4 mr-2" />
                Voltar
              </Button>
              <div>
                <h1 className="text-xl">{project.name}</h1>
                <p className="text-sm text-gray-600">
                  Versão {document.version} • Última edição: {new Date(document.updatedAt).toLocaleString('pt-BR')} por {document.updatedBy}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-4">
              {/* Usuários ativos */}
              <div className="flex items-center gap-2">
                <span className="text-sm text-gray-600">Colaboradores:</span>
                <div className="flex -space-x-2">
                  {activeUsers.map(user => (
                    <Avatar key={user.id} className="w-8 h-8 border-2 border-white">
                      <AvatarFallback className="bg-blue-600 text-white text-xs">
                        {user.name.split(' ').map(n => n[0]).join('').slice(0, 2)}
                      </AvatarFallback>
                    </Avatar>
                  ))}
                </div>
              </div>

              {saving && (
                <Badge variant="secondary" className="animate-pulse">
                  Salvando...
                </Badge>
              )}

              <Button variant="outline" size="sm" onClick={() => setSettingsOpen(true)}>
                <Settings className="w-4 h-4 mr-2" />
                Configurações
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Editor */}
      <main className="flex-1 overflow-auto">
        <DocumentEditor 
          document={document} 
          onSave={handleSave}
          projectId={projectId}
        />
      </main>

      {/* Settings Sidebar */}
      <Sheet open={settingsOpen} onOpenChange={setSettingsOpen}>
        <SheetContent className="w-full sm:max-w-2xl overflow-y-auto">
          <SheetHeader>
            <SheetTitle>Configurações do Projeto</SheetTitle>
            <SheetDescription>
              Gerencie fontes de dados, participantes e histórico
            </SheetDescription>
          </SheetHeader>

          <Tabs defaultValue="datasources" className="mt-6">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="datasources">Fontes de Dados</TabsTrigger>
              <TabsTrigger value="participants">Participantes</TabsTrigger>
              <TabsTrigger value="history">Histórico</TabsTrigger>
            </TabsList>

            <TabsContent value="datasources" className="mt-4">
              <DataSourcesPanel projectId={projectId} />
            </TabsContent>

            <TabsContent value="participants" className="mt-4">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm">Membros do Projeto</h3>
                  <Button size="sm">
                    <Users className="w-4 h-4 mr-2" />
                    Adicionar Membro
                  </Button>
                </div>
                
                <div className="space-y-2">
                  {activeUsers.map(user => (
                    <div key={user.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center gap-3">
                        <Avatar className="w-10 h-10">
                          <AvatarFallback className="bg-blue-100 text-blue-700">
                            {user.name.split(' ').map(n => n[0]).join('').slice(0, 2)}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="text-sm">{user.name}</p>
                          <p className="text-xs text-gray-600">{user.email}</p>
                        </div>
                      </div>
                      <Badge variant="outline">
                        {user.role === 'admin' ? 'Admin' : user.role === 'manager' ? 'Gerente' : 'Membro'}
                      </Badge>
                    </div>
                  ))}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="history" className="mt-4">
              <AuditPanel projectId={projectId} />
            </TabsContent>
          </Tabs>
        </SheetContent>
      </Sheet>

      {/* AI Chat Assistant */}
      <AIChat projectId={projectId} />
    </div>
  );
}