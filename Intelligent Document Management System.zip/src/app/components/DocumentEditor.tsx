import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { Card } from './ui/card';
import { Sparkles, RotateCw } from 'lucide-react';
import { apiService, type Document } from '../../services/api';
import { toast } from 'sonner';

interface DocumentEditorProps {
  document: Document;
  onSave: (content: Document['content']) => void;
  projectId: string;
}

export function DocumentEditor({ document, onSave, projectId }: DocumentEditorProps) {
  const [content, setContent] = useState(document.content);
  const [generatingSection, setGeneratingSection] = useState<string | null>(null);

  useEffect(() => {
    setContent(document.content);
  }, [document]);

  const handleSectionChange = (sectionId: string, newContent: string) => {
    const updatedContent = {
      ...content,
      sections: content.sections.map(section =>
        section.id === sectionId
          ? { ...section, content: newContent }
          : section
      )
    };
    setContent(updatedContent);
    
    // Auto-save após 1 segundo
    const timer = setTimeout(() => {
      onSave(updatedContent);
    }, 1000);

    return () => clearTimeout(timer);
  };

  const handleGenerateWithAI = async (sectionId: string) => {
    setGeneratingSection(sectionId);
    toast.info('🤖 Gerando conteúdo com IA...', {
      description: 'Analisando documentos e contexto do projeto'
    });

    try {
      const aiContent = await apiService.generateWithAI(projectId, sectionId);
      
      const updatedContent = {
        ...content,
        sections: content.sections.map(section =>
          section.id === sectionId
            ? { ...section, content: aiContent }
            : section
        )
      };
      
      setContent(updatedContent);
      onSave(updatedContent);
      toast.success('✅ Conteúdo gerado com sucesso!', {
        description: 'O conteúdo foi adicionado à seção'
      });
    } catch (error: any) {
      console.error('Erro ao gerar conteúdo:', error);
      
      // Mensagens de erro personalizadas
      const errorMessage = error.message || 'Erro desconhecido ao gerar conteúdo';
      
      if (errorMessage.includes('Configure a API')) {
        toast.error('⚙️ Configuração necessária', {
          description: 'Clique em "Configurar API" no topo da página para adicionar sua chave de IA',
          duration: 6000
        });
      } else if (errorMessage.includes('API key inválida')) {
        toast.error('🔑 Chave de API inválida', {
          description: 'Verifique sua chave nas configurações e tente novamente',
          duration: 5000
        });
      } else if (errorMessage.includes('Limite de requisições')) {
        toast.error('⏱️ Limite excedido', {
          description: 'Aguarde alguns minutos antes de tentar novamente',
          duration: 5000
        });
      } else if (errorMessage.includes('conexão')) {
        toast.error('🌐 Erro de conexão', {
          description: 'Verifique sua conexão com a internet',
          duration: 5000
        });
      } else {
        toast.error('❌ Erro ao gerar conteúdo', {
          description: errorMessage,
          duration: 5000
        });
      }
    } finally {
      setGeneratingSection(null);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-6 py-8">
      {/* Document Title */}
      <div className="mb-8 pb-6 border-b">
        <h1 className="text-3xl mb-2">Especificação de Requisitos</h1>
        <p className="text-gray-600">
          {document.projectId} - Documento de especificação gerado automaticamente
        </p>
      </div>

      {/* Sections */}
      <div className="space-y-8">
        {content.sections.map((section) => (
          <Card key={section.id} className="p-6">
            <div className="flex items-start justify-between mb-4">
              <h2 className="text-2xl">{section.title}</h2>
              <div className="flex gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleGenerateWithAI(section.id)}
                  disabled={generatingSection === section.id}
                >
                  {generatingSection === section.id ? (
                    <>
                      <RotateCw className="w-4 h-4 mr-2 animate-spin" />
                      Gerando...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 mr-2" />
                      Gerar com IA
                    </>
                  )}
                </Button>
              </div>
            </div>

            {section.isEditable ? (
              <Textarea
                value={section.content}
                onChange={(e) => handleSectionChange(section.id, e.target.value)}
                placeholder="Digite o conteúdo desta seção ou use a IA para gerar automaticamente..."
                className="min-h-[200px] font-mono text-sm"
              />
            ) : (
              <div className="prose prose-sm max-w-none">
                <p className="whitespace-pre-wrap">{section.content}</p>
              </div>
            )}

            <div className="mt-4 text-xs text-gray-500">
              Última edição: {new Date(document.updatedAt).toLocaleString('pt-BR')}
            </div>
          </Card>
        ))}
      </div>

      {/* Footer Info */}
      <div className="mt-12 p-6 bg-gray-50 rounded-lg">
        <h3 className="text-sm mb-2">ℹ️ Informações sobre a IA</h3>
        <ul className="text-xs text-gray-700 space-y-1">
          <li>• A IA analisa apenas documentos enviados para este projeto</li>
          <li>• Não cria novas seções nem altera a estrutura do documento</li>
          <li>• Quando não encontra informação, escreve "Não identificado"</li>
          <li>• Todas as gerações são registradas no histórico de auditoria</li>
          <li>• Você pode editar manualmente qualquer conteúdo gerado</li>
        </ul>
      </div>
    </div>
  );
}