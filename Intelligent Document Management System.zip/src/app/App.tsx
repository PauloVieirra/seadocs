import { useState, useEffect } from 'react';
import { LoginScreen } from './components/LoginScreen';
import { Dashboard } from './components/Dashboard';
import { ProjectEditor } from './components/ProjectEditor';
import { apiService, type User } from '../services/api';
import { Toaster } from './components/ui/sonner';

type AppView = 'login' | 'dashboard' | 'editor';

export default function App() {
  const [view, setView] = useState<AppView>('login');
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(null);

  useEffect(() => {
    // Verificar se usuário já está logado
    const user = apiService.getCurrentUser();
    if (user) {
      setCurrentUser(user);
      setView('dashboard');
    }
  }, []);

  const handleLoginSuccess = (user: User) => {
    setCurrentUser(user);
    setView('dashboard');
  };

  const handleLogout = () => {
    apiService.logout();
    setCurrentUser(null);
    setSelectedProjectId(null);
    setView('login');
  };

  const handleProjectSelect = (projectId: string) => {
    setSelectedProjectId(projectId);
    setView('editor');
  };

  const handleBackToDashboard = () => {
    setSelectedProjectId(null);
    setView('dashboard');
  };

  return (
    <>
      {view === 'login' && (
        <LoginScreen onLoginSuccess={handleLoginSuccess} />
      )}

      {view === 'dashboard' && currentUser && (
        <Dashboard
          user={currentUser}
          onProjectSelect={handleProjectSelect}
          onLogout={handleLogout}
        />
      )}

      {view === 'editor' && selectedProjectId && (
        <ProjectEditor
          projectId={selectedProjectId}
          onBack={handleBackToDashboard}
        />
      )}

      <Toaster position="top-right" />
    </>
  );
}
