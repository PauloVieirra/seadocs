
  # Intelligent Document Management System

  This is a code bundle for Intelligent Document Management System. The original project is available at https://www.figma.com/design/1DNBuiYxc4p34nIsmSuZyF/Intelligent-Document-Management-System.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  